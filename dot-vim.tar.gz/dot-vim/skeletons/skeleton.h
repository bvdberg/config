#ifndef <HEADER> 
#define <HEADER>

namespace mynamespace {

class <CLASSNAME> {
public:
    <CLASSNAME>();
    virtual ~<CLASSNAME>();
private:
    <CLASSNAME>(const <CLASSNAME>&);
    <CLASSNAME>& operator= (const <CLASSNAME>&);
};

}

#endif
